from flask import Flask, render_template, request, redirect, url_for, jsonify, send_file
from pymongo import MongoClient
from datetime import datetime
import csv
from io import StringIO
import requests
import base64

app = Flask(__name__)

# MongoDB connection
def connect_to_mongodb():
    try:
        client = MongoClient(
            "mongodb+srv://manjitsingh121ion:exkMQIFDAF9ygDXi@ionsite.ejkpg.mongodb.net/?retryWrites=true&w=majority&appName=IonSite"
        )
        db = client["DigitalTwin"]
        collection = db["SensorData"]
        print("Connected to MongoDB Atlas successfully!")
        return collection
    except Exception as e:
        print(f"Error connecting to MongoDB Atlas: {e}")
        return None

def refresh_token(refresh_token):
    url = "https://api.aquareporter.com.au/token/refresh/"
    headers = {"Authorization": f"Bearer {refresh_token}"}
    try:
        response = requests.post(url, headers=headers)
        response.raise_for_status()
        tokens = response.json()
        return tokens.get("access_token")
    except requests.RequestException as e:
        print(f"Token Refresh Error: {e}")
        return None

# Function to sanitize documents for MongoDB
def sanitize_document(doc):
    """
    Recursively sanitize a document to replace invalid keys (e.g., '$').
    """
    if isinstance(doc, dict):
        sanitized = {}
        for key, value in doc.items():
            sanitized_key = key.replace("$", "_dollar_")
            sanitized[sanitized_key] = sanitize_document(value)
        return sanitized
    elif isinstance(doc, list):
        return [sanitize_document(item) for item in doc]
    else:
        return doc

# Function to log in and fetch access token
def fetch_access_token(username, password):
    url = "https://api.aquareporter.com.au/login/"
    auth = "Basic " + base64.b64encode(f"{username}:{password}".encode()).decode()
    headers = {"Authorization": auth}
    try:
        response = requests.post(url, headers=headers)
        response.raise_for_status()
        tokens = response.json()
        return tokens.get("access_token"), tokens.get("refresh_token")
    except requests.RequestException as e:
        print(f"Login Failed: {e}")
        return None, None

# Function to fetch recent data
def fetch_recent_data(access_token, unit_id, data_type):
    url = f"https://api.aquareporter.com.au/api/v2/{data_type}"
    headers = {"Authorization": f"Bearer {access_token}"}
    body = {"unitId": int(unit_id)}  # Ensure unitId is an integer

    try:
        print(f"Sending request to {url}")
        print(f"Headers: {headers}")
        print(f"Body: {body}")

        response = requests.get(url, headers=headers, json=body)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx, 5xx)
        data = response.json()
        print(f"Fetched Data: {data}")
        return data
    except requests.RequestException as e:
        print(f"Error fetching recent data: {e}")
        if hasattr(e, 'response') and e.response is not None:
            print(f"Response Status Code: {e.response.status_code}")
            print(f"Response Text: {e.response.text}")
        return None

# Function to fetch data with a specified range
def fetch_data_with_range(access_token, unit_id, data_type, from_datetime, count):
    url = f"https://api.aquareporter.com.au/api/v2/{data_type}"
    headers = {"Authorization": f"Bearer {access_token}"}
    body = {"unitId": int(unit_id), "fromDateTime": from_datetime, "count": count}

    try:
        response = requests.get(url, headers=headers, json=body)
        response.raise_for_status()
        return sanitize_document(response.json())
    except requests.RequestException as e:
        print(f"Error fetching data with range: {e}")
        return None

# Home page (Step 1: Login)
@app.route("/", methods=["GET"])
def home():
    return render_template("index.html")

@app.route("/login", methods=["POST"])
def login():
    username = request.form["username"]
    password = request.form["password"]
    access_token, refresh_token = fetch_access_token(username, password)
    if access_token:
        return redirect(url_for("unit", access_token=access_token))
    else:
        return render_template("index.html", error="Invalid credentials. Please try again.")

# Unit ID input (Step 2)
@app.route("/unit", methods=["GET"])
def unit():
    access_token = request.args.get("access_token")
    return render_template("unit.html", access_token=access_token)

@app.route("/unit", methods=["POST"])
def unit_post():
    access_token = request.form["access_token"]
    unit_id = request.form["unit_id"]
    return redirect(url_for("data_type_selection", access_token=access_token, unit_id=unit_id))

# Data type selection (Step 3)
@app.route("/data_type_selection/<access_token>/<unit_id>", methods=["GET"])
def data_type_selection(access_token, unit_id):
    return render_template("data_type.html", access_token=access_token, unit_id=unit_id)

@app.route("/data_type_selection", methods=["POST"])
def data_type_selection_post():
    access_token = request.form["access_token"]
    unit_id = request.form["unit_id"]
    data_type = request.form["data_type"]

    if data_type in ["GetOneMinDatalog", "Get30MinDatalog"]:
        return redirect(url_for("date_input", access_token=access_token, unit_id=unit_id, data_type=data_type))
    else:
        return redirect(url_for("logs", access_token=access_token, unit_id=unit_id, data_type=data_type, from_date="None"))

# Date input (Step 4)
@app.route("/date_input/<access_token>/<unit_id>/<data_type>", methods=["GET"])
def date_input(access_token, unit_id, data_type):
    return render_template("date_input.html", access_token=access_token, unit_id=unit_id, data_type=data_type)

@app.route("/date_input", methods=["POST"])
def date_input_post():
    access_token = request.form["access_token"]
    unit_id = request.form["unit_id"]
    data_type = request.form["data_type"]
    from_date_str = request.form["from_date"]

    try:
        if len(from_date_str) == 16:  # Format is YYYY-MM-DDTHH:MM
            from_date_str += ":00"
        from_datetime = int(datetime.strptime(from_date_str, "%Y-%m-%dT%H:%M:%S").timestamp())
        return redirect(url_for("logs", access_token=access_token, unit_id=unit_id, data_type=data_type, from_date=from_datetime))
    except ValueError:
        return jsonify({"error": "Invalid date format. Use YYYY-MM-DD HH:MM:SS"})

# Logs input (Step 5)
@app.route("/logs/<access_token>/<unit_id>/<data_type>/<from_date>", methods=["GET"])
def logs(access_token, unit_id, data_type, from_date):
    return render_template("logs.html", access_token=access_token, unit_id=unit_id, data_type=data_type, from_date=from_date)

@app.route("/logs", methods=["POST"])
def logs_post():
    access_token = request.form["access_token"]
    unit_id = request.form["unit_id"]
    data_type = request.form["data_type"]
    from_date = request.form["from_date"]
    count = request.form["count"]

    if not count.isdigit() or not (1 <= int(count) <= 48):
        return jsonify({"error": "Count must be between 1 and 48"})

    try:
        # Fetch data based on data_type
        if data_type in ["GetOneMinDatalog", "Get30MinDatalog"]:
            if from_date == "None":
                return jsonify({"error": "Date and time must be provided for this data type."})
            data = fetch_data_with_range(access_token, unit_id, data_type, int(from_date), int(count))
        else:
            data = fetch_recent_data(access_token, unit_id, data_type)

        if data:
            sanitized_data = sanitize_document(data)
            collection = connect_to_mongodb()
            if collection is not None:
                # Insert data into MongoDB
                print("Inserting sanitized data into MongoDB...")
                if isinstance(sanitized_data, list):
                    collection.insert_many(sanitized_data)
                else:
                    collection.insert_one(sanitized_data)
                print("Data insertion successful.")
                return redirect(url_for("dashboard", unit_id=unit_id, data_type=data_type))
            else:
                return jsonify({"error": "Database connection failed"})
        else:
            return jsonify({"error": "No data fetched from API"})
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({"error": str(e)})

# Dashboard (Step 6)
@app.route("/dashboard/<unit_id>/<data_type>", methods=["GET"])
def dashboard(unit_id, data_type):
    collection = connect_to_mongodb()
    if collection is not None:
        try:
            # Query for data associated with the unit_id and data_type
            data = list(collection.find({"unitId": int(unit_id), "data_type": data_type}))
            if data:
                return render_template("dashboard.html", data=data, data_type=data_type, unit_id=unit_id)
            else:
                return jsonify({"error": "No data found in the database for the specified criteria."})
        except Exception as e:
            print(f"Database Query Error: {e}")
            return jsonify({"error": "Error retrieving data from the database"})
    else:
        return jsonify({"error": "Database connection failed"})


# Download CSV (Step 5)
@app.route("/download/<data_type>", methods=["GET"])
def download_data(data_type):
    collection = connect_to_mongodb()
    if collection:
        data = list(collection.find({"data_type": data_type}))
        csv_data = StringIO()
        writer = csv.writer(csv_data)
        writer.writerow(data[0].keys())  # Headers
        for row in data:
            writer.writerow(row.values())
        csv_data.seek(0)
        return send_file(
            csv_data,
            mimetype="text/csv",
            as_attachment=True,
            download_name=f"{data_type}.csv"
        )
    else:
        return jsonify({"error": "Database connection failed"})

if __name__ == "__main__":
    app.run(debug=True)

