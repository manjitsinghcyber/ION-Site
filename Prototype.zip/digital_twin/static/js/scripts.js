// document.addEventListener("DOMContentLoaded", () => {
//     const loginForm = document.getElementById("loginForm");
//     const unitForm = document.getElementById("unitForm");
//     const fetchForm = document.getElementById("fetchForm");

//     if (loginForm) {
//         loginForm.addEventListener("submit", async (e) => {
//             e.preventDefault();
//             const formData = new FormData(loginForm);
//             const response = await fetch("/login", { method: "POST", body: formData });
//             const result = await response.json();
//             if (result.success) {
//                 window.location.href = "/unit";
//             } else {
//                 alert("Login Failed!");
//             }
//         });
//     }

//     if (unitForm) {
//         unitForm.addEventListener("submit", (e) => {
//             e.preventDefault();
//             const dataType = unitForm.querySelector("select").value;
//             window.location.href = `/fetch?data_type=${dataType}`;
//         });
//     }

//     if (fetchForm) {
//         fetchForm.addEventListener("submit", async (e) => {
//             e.preventDefault();
//             const formData = new FormData(fetchForm);
//             const response = await fetch("/fetch_data", { method: "POST", body: formData });
//             const result = await response.json();
//             if (result.success) {
//                 alert("Data fetched successfully!");
//             } else {
//                 alert("Error fetching data!");
//             }
//         });
//     }
// });


// document.addEventListener("DOMContentLoaded", () => {
//     let accessToken = "";

//     document.getElementById("loginForm").addEventListener("submit", async (e) => {
//         e.preventDefault();
//         const formData = new FormData(e.target);
//         const response = await fetch("/login", { method: "POST", body: formData });
//         const result = await response.json();
//         if (result.success) {
//             alert("Login Successful!");
//             window.location.href = "/unit?access_token=" + result.access_token;
//         } else {
//             alert("Login Failed: " + result.message);
//             window.location.reload(); // Reload the page
//         }
//     });
    

//     // Unit form submission
//     const unitForm = document.getElementById("unitForm");
//     if (unitForm) {
//         unitForm.addEventListener("submit", async (e) => {
//             e.preventDefault();
//             const formData = new FormData(unitForm);
//             const response = await fetch(`/unit`, { method: "POST", body: formData });
//             if (response.redirected) {
//                 window.location.href = response.url; // Redirect to data type selection
//             } else {
//                 alert("Error processing Unit ID.");
//             }
//         });
//     }

//     // Data type selection form submission
//     const dataTypeForm = document.getElementById("dataTypeForm");
//     if (dataTypeForm) {
//         dataTypeForm.addEventListener("submit", async (e) => {
//             e.preventDefault();
//             const formData = new FormData(dataTypeForm);
//             const dataType = formData.get("data_type");
//             const unitId = dataTypeForm.getAttribute("data-unit-id");
//             if (dataType === "GetOneMinDatalog" || dataType === "Get30MinDatalog") {
//                 window.location.href = `/date_input/${unitId}/${dataType}`;
//             } else {
//                 window.location.href = `/logs/${unitId}/${dataType}/None`;
//             }
//         });
//     }

//     document.getElementById("dateForm").addEventListener("submit", (e) => {
//         e.preventDefault();
//         const dateInput = document.getElementById("from_date").value;
//         if (!/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(dateInput)) {
//             alert("Invalid date format. Use YYYY-MM-DD HH:MM:SS.");
//             return;
//         }
//         e.target.submit();
//     });
    

//     // Logs form submission
//     document.getElementById("logsForm").addEventListener("submit", (e) => {
//         e.preventDefault();
//         const count = document.getElementById("count").value;
//         if (isNaN(count) || count < 1 || count > 48) {
//             alert("Log count must be between 1 and 48.");
//             return;
//         }
//         e.target.submit();
//     });
    

//     // Download button
//     const downloadButton = document.getElementById("downloadButton");
//     if (downloadButton) {
//         downloadButton.addEventListener("click", async () => {
//             const dataType = downloadButton.getAttribute("data-data-type");
//             const response = await fetch(`/download?data_type=${dataType}`);
//             if (response.ok) {
//                 const blob = await response.blob();
//                 const url = window.URL.createObjectURL(blob);
//                 const a = document.createElement("a");
//                 a.style.display = "none";
//                 a.href = url;
//                 a.download = `${dataType}.csv`;
//                 document.body.appendChild(a);
//                 a.click();
//                 window.URL.revokeObjectURL(url);
//                 alert("Data downloaded successfully!");
//             } else {
//                 const result = await response.json();
//                 alert("Error downloading data: " + result.error);
//             }
//         });
//     }
// });


// document.addEventListener("DOMContentLoaded", () => {
//     // Login Form
//     const loginForm = document.getElementById("loginForm");
//     if (loginForm) {
//         loginForm.addEventListener("submit", async (e) => {
//             e.preventDefault();
//             const formData = new FormData(loginForm);
//             const response = await fetch("/login", { method: "POST", body: formData });
//             const result = await response.json();

//             if (result.success) {
//                 alert("Login Successful!");
//                 window.location.href = `/unit?access_token=${result.access_token}`;
//             } else {
//                 alert("Invalid credentials. Please try again.");
//                 window.location.reload();
//             }
//         });
//     }

//     // Unit Selection Form
//     const unitForm = document.getElementById("unitForm");
//     if (unitForm) {
//         unitForm.addEventListener("submit", (e) => {
//             e.preventDefault();
//             const accessToken = unitForm.getAttribute("data-access-token");
//             const unitId = document.getElementById("unitId").value;

//             if (!unitId) {
//                 alert("Please enter a valid Unit ID.");
//                 return;
//             }

//             window.location.href = `/data_type/${accessToken}/${unitId}`;
//         });
//     }

//     // Data Type Form
//     const dataTypeForm = document.getElementById("dataTypeForm");
//     if (dataTypeForm) {
//         dataTypeForm.addEventListener("submit", (e) => {
//             e.preventDefault();
//             const dataType = document.getElementById("dataType").value;
//             const unitId = dataTypeForm.getAttribute("data-unit-id");

//             if (dataType === "GetOneMinDatalog" || dataType === "Get30MinDatalog") {
//                 window.location.href = `/date_input/${unitId}/${dataType}`;
//             } else {
//                 window.location.href = `/logs/${unitId}/${dataType}/None`;
//             }
//         });
//     }

//     // Date Form
//     const dateForm = document.getElementById("dateForm");
//     if (dateForm) {
//         dateForm.addEventListener("submit", (e) => {
//             e.preventDefault();
//             const fromDate = document.getElementById("from_date").value;

//             // Validate the date format
//             if (!/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(fromDate)) {
//                 alert("Invalid date format. Please use the format: YYYY-MM-DD HH:MM:SS.");
//                 return;
//             }

//             e.target.submit();
//         });
//     }

//     // Logs Form
//     const logsForm = document.getElementById("logsForm");
//     if (logsForm) {
//         logsForm.addEventListener("submit", (e) => {
//             e.preventDefault();
//             const count = document.getElementById("count").value;

//             // Validate log count
//             if (isNaN(count) || count < 1 || count > 48) {
//                 const countError = document.getElementById("count-error");
//                 if (countError) {
//                     countError.textContent = "Log count must be between 1 and 48.";
//                 }
//                 return;
//             }

//             // Disable the submit button to prevent multiple submissions
//             const submitButton = logsForm.querySelector("button[type='submit']");
//             if (submitButton) {
//                 submitButton.disabled = true;
//                 submitButton.textContent = "Submitting...";
//             }

//             e.target.submit();
//         });
//     }

//     // Download Button
//     const downloadButton = document.getElementById("downloadButton");
//     if (downloadButton) {
//         downloadButton.addEventListener("click", async () => {
//             const dataType = downloadButton.getAttribute("data-data-type");
//             const response = await fetch(`/download?data_type=${dataType}`);

//             if (response.ok) {
//                 const blob = await response.blob();
//                 const url = window.URL.createObjectURL(blob);
//                 const a = document.createElement("a");
//                 a.style.display = "none";
//                 a.href = url;
//                 a.download = `${dataType}.csv`;
//                 document.body.appendChild(a);
//                 a.click();
//                 window.URL.revokeObjectURL(url);
//                 alert("Data downloaded successfully!");
//             } else {
//                 const result = await response.json();
//                 alert("Error downloading data: " + result.error);
//             }
//         });
//     }
// });



// Login Form - POST Request
const loginForm = document.getElementById("loginForm");
if (loginForm) {
    loginForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formData = new FormData(loginForm);
        const response = await fetch("/login", {
            method: "POST",
            body: formData
        });

        const result = await response.json();
        if (result.status) {
            window.location.href = "/home"; // Redirect to home page on successful login
        } else {
            alert(result.message); // Show error message on failure
        }
    });
}

window.onload = function() {
    // Get the query parameter "error" from the URL
    const urlParams = new URLSearchParams(window.location.search);
    const errorMessage = urlParams.get('error');
    
    // If an error message exists, show an alert
    if (errorMessage) {
        alert(errorMessage);
    }
};

// Unit Selection Form - GET Request (Corrected)
const unitForm = document.getElementById("unitForm");
if (unitForm) {
    unitForm.addEventListener("submit", (e) => {
        e.preventDefault();
        const accessToken = unitForm.getAttribute("data-access-token");
        const unitId = document.getElementById("unitId").value;

        if (!unitId) {
            alert("Please enter a valid Unit ID.");
            return;
        }

        // Use GET method by redirecting to the URL with query parameters
        window.location.href = `/data_type?access_token=${accessToken}&unitId=${unitId}`;
    });
}

// Data Type Form - GET Request (Corrected)
const dataTypeForm = document.getElementById("dataTypeForm");
if (dataTypeForm) {
    dataTypeForm.addEventListener("submit", (e) => {
        e.preventDefault();
        const dataType = document.getElementById("dataType").value;
        const unitId = dataTypeForm.getAttribute("data-unit-id");

        // Use GET method for navigation
        window.location.href = `/date_input/${unitId}?dataType=${dataType}`;
    });
}

// Date Form - POST Request (Corrected, but could be GET based on your need)
const dateForm = document.getElementById("dateForm");
if (dateForm) {
    dateForm.addEventListener("submit", (e) => {
        e.preventDefault();
        e.target.submit(); // Submit the form (POST request)
    });
}

// Logs Form - POST Request (Corrected)
const logsForm = document.getElementById("logsForm");
if (logsForm) {
    logsForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formData = new FormData(logsForm);
        const response = await fetch("/logs", {
            method: "POST",
            body: formData
        });

        const result = await response.json();
        if (result.status) {
            alert("Logs submitted successfully!");
        } else {
            alert("Error submitting logs.");
        }
    });
}

// Download Button - GET Request (Correct)
const downloadButton = document.getElementById("downloadButton");
if (downloadButton) {
    downloadButton.addEventListener("click", async () => {
        const dataType = document.getElementById("dataType").value;
        const response = await fetch(`/download?data_type=${dataType}`);
        const result = await response.blob();
        const link = document.createElement("a");
        link.href = URL.createObjectURL(result);
        link.download = `${dataType}_data.csv`;
        link.click();
    });
}